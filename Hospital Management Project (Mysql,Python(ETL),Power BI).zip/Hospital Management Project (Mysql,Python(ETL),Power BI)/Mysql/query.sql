#task1:Total appointments per doctor
SELECT d.first_name, d.last_name, COUNT(a.appointment_id) AS total_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY total_appointments DESC;
#task2:Total appointments per day
SELECT appointment_date, COUNT(*) AS total_appointments
FROM Appointments
GROUP BY appointment_date
ORDER BY appointment_date;
#task3:Appointments by status (Completed, Cancelled, Pending)
SELECT status, COUNT(*) AS count
FROM Appointments
GROUP BY status;
#Patients with most appointments
SELECT p.first_name, p.last_name, COUNT(a.appointment_id) AS appointment_count
FROM Appointments a
JOIN Patients p ON a.patient_id = p.patient_id
GROUP BY p.patient_id
ORDER BY appointment_count DESC
LIMIT 10;
#task5:Average number of appointments per doctor
SELECT AVG(appointment_count) AS avg_appointments
FROM (
    SELECT doctor_id, COUNT(*) AS appointment_count
    FROM Appointments
    GROUP BY doctor_id
) AS sub;
#Appointments per hospital branch

SELECT d.hospital_branch, COUNT(a.appointment_id) AS total_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch
ORDER BY total_appointments DESC;

#task7: Appointments per specialization
SELECT d.specialization, COUNT(a.appointment_id) AS total_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.specialization
ORDER BY total_appointments DESC;

#task8:Patients by gender
SELECT gender, COUNT(*) AS patient_count
FROM Patients
GROUP BY gender;

#task9:Patients by age group
SELECT 
    CASE 
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 18 THEN '0-17'
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 18 AND 35 THEN '18-35'
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 36 AND 60 THEN '36-60'
        ELSE '60+' 
    END AS age_group,
    COUNT(*) AS patient_count
FROM Patients
GROUP BY age_group;

#task10:New patient registrations per month
SELECT DATE_FORMAT(registration_date, '%Y-%m') AS month, COUNT(*) AS new_patients
FROM Patients
GROUP BY month
ORDER BY month;

#task11:Top 10 doctors by number of patients treated

SELECT d.first_name, d.last_name, COUNT(DISTINCT a.patient_id) AS patients_treated
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY patients_treated DESC
LIMIT 10;
#task12:Average years of experience per specialization
SELECT specialization, AVG(years_experience) AS avg_experience
FROM Doctors
GROUP BY specialization
ORDER BY avg_experience DESC;

#task13:Total treatments per treatment type
SELECT treatment_type, COUNT(*) AS total_treatments
FROM Treatments
GROUP BY treatment_type
ORDER BY total_treatments DESC;
#14:Average treatment cost per treatment type
SELECT treatment_type, AVG(cost) AS avg_cost
FROM Treatments
GROUP BY treatment_type
ORDER BY avg_cost DESC;
#Total revenue per hospital branch
SELECT d.hospital_branch, SUM(b.amount) AS total_revenue
FROM Billing b
JOIN Appointments a ON b.treatment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch
ORDER BY total_revenue DESC;

#task16:Total revenue per doctor
SELECT d.first_name, d.last_name, SUM(b.amount) AS total_revenue
FROM Billing b
JOIN Appointments a ON b.treatment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY total_revenue DESC
LIMIT 10;

#17:Revenue by payment method
SELECT payment_method, SUM(amount) AS total_revenue
FROM Billing
GROUP BY payment_method
ORDER BY total_revenue DESC;
#task18:Revenue by payment status
SELECT payment_status, SUM(amount) AS total_revenue
FROM Billing
GROUP BY payment_status;

#task19:Top 10 treatments generating maximum revenue
SELECT t.treatment_type, SUM(b.amount) AS revenue_generated
FROM Treatments t
JOIN Billing b ON t.treatment_id = b.treatment_id
GROUP BY t.treatment_type
ORDER BY revenue_generated DESC
LIMIT 10;
#20:Treatments performed per month

SELECT DATE_FORMAT(treatment_date, '%Y-%m') AS month, COUNT(*) AS total_treatments
FROM Treatments
GROUP BY month
ORDER BY month;
#Appointments, Patients & Insurance Analysis
#21:Completed vs Cancelled appointments per month
SELECT DATE_FORMAT(appointment_date, '%Y-%m') AS month, status, COUNT(*) AS total
FROM Appointments
GROUP BY month, status
ORDER BY month;
#22:Average number of appointments per patient
SELECT AVG(appointment_count) AS avg_appointments
FROM (
    SELECT patient_id, COUNT(*) AS appointment_count
    FROM Appointments
    GROUP BY patient_id
) AS sub;

#23:Patients per hospital branch (via doctor appointments)
SELECT d.hospital_branch, COUNT(DISTINCT a.patient_id) AS total_patients
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch
ORDER BY total_patients DESC;

#24:Patient distribution by age group & gender
SELECT 
    CASE 
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 18 THEN '0-17'
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 18 AND 35 THEN '18-35'
        WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 36 AND 60 THEN '36-60'
        ELSE '60+' 
    END AS age_group,
    gender,
    COUNT(*) AS patient_count
FROM Patients
GROUP BY age_group, gender
ORDER BY age_group;
#25:Patients with insurance vs without insurance
SELECT 
    CASE WHEN insurance_provider IS NULL OR insurance_provider = '' THEN 'No Insurance' ELSE 'With Insurance' END AS insurance_status,
    COUNT(*) AS patient_count
FROM Patients
GROUP BY insurance_status;

#26:Revenue per insurance provider
SELECT p.insurance_provider, SUM(b.amount) AS total_revenue
FROM Billing b
JOIN Patients p ON b.patient_id = p.patient_id
WHERE p.insurance_provider IS NOT NULL
GROUP BY p.insurance_provider
ORDER BY total_revenue DESC
LIMIT 10;

#Average treatment cost per insurance provider
SELECT p.insurance_provider, AVG(t.cost) AS avg_treatment_cost
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Patients p ON a.patient_id = p.patient_id
WHERE p.insurance_provider IS NOT NULL
GROUP BY p.insurance_provider
ORDER BY avg_treatment_cost DESC;

#28:Top 10 most frequent treatment types

SELECT treatment_type, COUNT(*) AS frequency
FROM Treatments
GROUP BY treatment_type
ORDER BY frequency DESC
LIMIT 10;

#Average number of treatments per patient

SELECT AVG(treatment_count) AS avg_treatments
FROM (
    SELECT a.patient_id, COUNT(t.treatment_id) AS treatment_count
    FROM Treatments t
    JOIN Appointments a ON t.appointment_id = a.appointment_id
    GROUP BY a.patient_id
) AS sub;

#30:Monthly revenue trend

SELECT DATE_FORMAT(bill_date, '%Y-%m') AS month, SUM(amount) AS total_revenue
FROM Billing
GROUP BY month
ORDER BY month;
#doctor Performance, Branch & Payment Analysis
#31:Top 10 doctors by revenue generated

SELECT d.first_name, d.last_name, SUM(b.amount) AS total_revenue
FROM Billing b
JOIN Treatments t ON b.treatment_id = t.treatment_id
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY total_revenue DESC
LIMIT 10;

#32:Average treatment cost per doctor
SELECT d.first_name, d.last_name, AVG(t.cost) AS avg_treatment_cost
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY avg_treatment_cost DESC;

#33:Average treatment cost per doctor
SELECT d.first_name, d.last_name, AVG(t.cost) AS avg_treatment_cost
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY avg_treatment_cost DESC;

#Number of patients treated per doctor

SELECT d.first_name, d.last_name, COUNT(DISTINCT a.patient_id) AS patients_treated
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id
ORDER BY patients_treated DESC;

#Revenue per hospital branch
SELECT d.hospital_branch, SUM(b.amount) AS total_revenue
FROM Billing b
JOIN Treatments t ON b.treatment_id = t.treatment_id
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch
ORDER BY total_revenue DESC;

#35:Average treatment cost per hospital branch
SELECT d.hospital_branch, AVG(t.cost) AS avg_treatment_cost
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch
ORDER BY avg_treatment_cost DESC;

#36:Appointments per branch by status
SELECT d.hospital_branch, a.status, COUNT(*) AS total_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch, a.status
ORDER BY d.hospital_branch;

#37:Revenue per payment method
SELECT payment_method, SUM(amount) AS total_revenue
FROM Billing
GROUP BY payment_method
ORDER BY total_revenue DESC;

#38:Revenue per payment status
SELECT payment_status, SUM(amount) AS total_revenue
FROM Billing
GROUP BY payment_status;

#39:Top 10 treatments by revenue per branch
SELECT d.hospital_branch, t.treatment_type, SUM(b.amount) AS revenue_generated
FROM Treatments t
JOIN Billing b ON t.treatment_id = b.treatment_id
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.hospital_branch, t.treatment_type
ORDER BY revenue_generated DESC
LIMIT 10;

#40:Average number of appointments per branch

SELECT d.hospital_branch, AVG(appointment_count) AS avg_appointments
FROM (
    SELECT d.hospital_branch, a.doctor_id, COUNT(*) AS appointment_count
    FROM Appointments a
    JOIN Doctors d ON a.doctor_id = d.doctor_id
    GROUP BY d.hospital_branch, a.doctor_id
) AS sub
GROUP BY d.hospital_branch
ORDER BY avg_appointments DESC;

#41:Top 10 patients by total amount billed

SELECT p.first_name, p.last_name, SUM(b.amount) AS total_billed
FROM Billing b
JOIN Patients p ON b.patient_id = p.patient_id
GROUP BY p.patient_id
ORDER BY total_billed DESC
LIMIT 10;
#42:Average billing amount per patient
SELECT AVG(total_billed) AS avg_billing_per_patient
FROM (
    SELECT patient_id, SUM(amount) AS total_billed
    FROM Billing
    GROUP BY patient_id
) AS sub;
#43:Revenue trend per doctor per month
SELECT d.first_name, d.last_name, DATE_FORMAT(b.bill_date, '%Y-%m') AS month, SUM(b.amount) AS monthly_revenue
FROM Billing b
JOIN Treatments t ON b.treatment_id = t.treatment_id
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id, month
ORDER BY month, monthly_revenue DESC;
#44:Top 10 treatments by number of patients
SELECT t.treatment_type, COUNT(DISTINCT a.patient_id) AS patients_count
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
GROUP BY t.treatment_type
ORDER BY patients_count DESC
LIMIT 10;
#45:Average treatment cost per patient
SELECT AVG(cost_per_patient) AS avg_treatment_cost
FROM (
    SELECT a.patient_id, AVG(t.cost) AS cost_per_patient
    FROM Treatments t
    JOIN Appointments a ON t.appointment_id = a.appointment_id
    GROUP BY a.patient_id
) AS sub;
#46:Monthly number of treatments by type
SELECT DATE_FORMAT(t.treatment_date, '%Y-%m') AS month, t.treatment_type, COUNT(*) AS treatment_count
FROM Treatments t
GROUP BY month, t.treatment_type
ORDER BY month, treatment_count DESC;
#47:Doctors with most canceled appointments
SELECT d.first_name, d.last_name, COUNT(*) AS canceled_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
WHERE a.status = 'Cancelled'
GROUP BY d.doctor_id
ORDER BY canceled_appointments DESC
LIMIT 10;
#48:Patients with most treatments
SELECT p.first_name, p.last_name, COUNT(t.treatment_id) AS total_treatments
FROM Treatments t
JOIN Appointments a ON t.appointment_id = a.appointment_id
JOIN Patients p ON a.patient_id = p.patient_id
GROUP BY p.patient_id
ORDER BY total_treatments DESC
LIMIT 10;

#49:Average treatment cost per month
SELECT DATE_FORMAT(treatment_date, '%Y-%m') AS month, AVG(cost) AS avg_treatment_cost
FROM Treatments
GROUP BY month
ORDER BY month;

#50:Revenue per treatment type per month
SELECT DATE_FORMAT(b.bill_date, '%Y-%m') AS month, t.treatment_type, SUM(b.amount) AS revenue
FROM Billing b
JOIN Treatments t ON b.treatment_id = t.treatment_id
GROUP BY month, t.treatment_type
ORDER BY month, revenue DESC;























CREATE DATABASE hospital_management;
USE hospital_management;

CREATE TABLE Appointments (
    appointment_id VARCHAR(20) PRIMARY KEY,
    patient_id VARCHAR(20),
    doctor_id VARCHAR(20),
    appointment_date DATE,
    appointment_time TIME,
    reason_for_visit VARCHAR(255),
    status VARCHAR(50)
);
CREATE TABLE Billing (
    bill_id VARCHAR(20) PRIMARY KEY,
    patient_id VARCHAR(20),
    treatment_id VARCHAR(20),
    bill_date DATE,
    amount DECIMAL(10,2),
    payment_method VARCHAR(50),
    payment_status VARCHAR(50)
);
CREATE TABLE Doctors (
    doctor_id VARCHAR(20) PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    specialization VARCHAR(100),
    phone_number BIGINT,
    years_experience INT,
    hospital_branch VARCHAR(100),
    email VARCHAR(100)
);
CREATE TABLE Patients (
    patient_id VARCHAR(20) PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    gender VARCHAR(10),
    date_of_birth DATE,
    contact_number BIGINT,
    address VARCHAR(255),
    registration_date DATE,
    insurance_provider VARCHAR(100),
    insurance_number VARCHAR(50),
    email VARCHAR(100)
);
CREATE TABLE Treatments (
    treatment_id VARCHAR(20) PRIMARY KEY,
    appointment_id VARCHAR(20),
    treatment_type VARCHAR(100),
    description TEXT,
    cost DECIMAL(10,2),
    treatment_date DATE
);


SELECT * FROM appointments;
SELECT * FROM billing;
